import mongoose from "mongoose";
const jobSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  companyName: { type: String, required: true, trim: true },
  jobTitle: { type: String, required: true, trim: true },
  location: { type: String, trim: true },
  jobType: { type: String, enum: ["Full Time", "Part Time", "Internship", "Contract"], default: "Full Time" },
  workMode: { type: String, enum: ["Remote", "Hybrid", "On-site"], default: "On-site" },
  salary: { type: String, trim: true },
  jobUrl: { type: String, trim: true },
  applicationDate: { type: Date, default: Date.now },
  status: { type: String, enum: ["Applied", "Interview", "Offer", "Rejected", "Withdrawn"], default: "Applied" },
  notes: { type: String },
}, { timestamps: true });
export default mongoose.model("Job", jobSchema);
