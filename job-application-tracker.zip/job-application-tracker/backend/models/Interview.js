import mongoose from "mongoose";
const interviewSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
  jobId: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
  date: { type: Date, required: true },
  time: { type: String },
  round: { type: String, default: "Round 1" },
  meetingLink: { type: String },
  notes: { type: String },
}, { timestamps: true });
export default mongoose.model("Interview", interviewSchema);
