import Interview from "../models/Interview.js";
import Job from "../models/Job.js";
const FIELDS = ["jobId", "date", "time", "round", "meetingLink", "notes"];
const pick = (body) => Object.fromEntries(FIELDS.filter((k) => body[k] !== undefined).map((k) => [k, body[k]]));

export async function getInterviews(req, res) {
  const filter = { userId: req.user._id };
  if (req.query.jobId) filter.jobId = req.query.jobId;
  res.json(await Interview.find(filter).populate("jobId", "companyName jobTitle").sort({ date: 1 }));
}
export async function createInterview(req, res) {
  if (!req.body.jobId || !req.body.date) return res.status(400).json({ message: "Application and interview date are required" });
  const job = await Job.findOne({ _id: req.body.jobId, userId: req.user._id });
  if (!job) return res.status(404).json({ message: "Application not found" });
  const iv = await Interview.create({ ...pick(req.body), userId: req.user._id });
  res.status(201).json(iv);
}
export async function updateInterview(req, res) {
  const data = pick(req.body); delete data.jobId;
  const iv = await Interview.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, data, { new: true, runValidators: true });
  iv ? res.json(iv) : res.status(404).json({ message: "Interview not found" });
}
export async function deleteInterview(req, res) {
  const iv = await Interview.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  iv ? res.json({ message: "Deleted" }) : res.status(404).json({ message: "Interview not found" });
}
