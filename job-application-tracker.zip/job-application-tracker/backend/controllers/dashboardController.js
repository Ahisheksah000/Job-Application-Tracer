import Job from "../models/Job.js";
import Interview from "../models/Interview.js";
export async function getStats(req, res) {
  const userId = req.user._id;
  const count = (status) => Job.countDocuments({ userId, ...(status && { status }) });
  const startOfToday = new Date(); startOfToday.setHours(0, 0, 0, 0);
  const [total, applied, interview, offer, rejected, recent, upcoming] = await Promise.all([
    count(), count("Applied"), count("Interview"), count("Offer"), count("Rejected"),
    Job.find({ userId }).sort({ createdAt: -1 }).limit(5),
    Interview.find({ userId, date: { $gte: startOfToday } }).populate("jobId", "companyName jobTitle").sort({ date: 1 }).limit(5),
  ]);
  res.json({ total, applied, interview, offer, rejected, recent, upcoming });
}
