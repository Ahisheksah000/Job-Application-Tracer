import Job from "../models/Job.js";
import Interview from "../models/Interview.js";
const escapeRegex = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const FIELDS = ["companyName", "jobTitle", "location", "jobType", "workMode", "salary", "jobUrl", "applicationDate", "status", "notes"];
const pick = (body) => Object.fromEntries(FIELDS.filter((k) => body[k] !== undefined).map((k) => [k, body[k]]));

export async function getJobs(req, res) {
  const { q, status, sort } = req.query;
  const filter = { userId: req.user._id };
  if (status) filter.status = String(status);
  if (q) { const r = new RegExp(escapeRegex(q), "i"); filter.$or = [{ companyName: r }, { jobTitle: r }]; }
  res.json(await Job.find(filter).sort({ applicationDate: sort === "oldest" ? 1 : -1 }));
}
export async function createJob(req, res) {
  if (!req.body.companyName || !req.body.jobTitle) return res.status(400).json({ message: "Company name and job title are required" });
  res.status(201).json(await Job.create({ ...pick(req.body), userId: req.user._id }));
}
export async function getJob(req, res) {
  const job = await Job.findOne({ _id: req.params.id, userId: req.user._id });
  job ? res.json(job) : res.status(404).json({ message: "Application not found" });
}
export async function updateJob(req, res) {
  const job = await Job.findOneAndUpdate({ _id: req.params.id, userId: req.user._id }, pick(req.body), { new: true, runValidators: true });
  job ? res.json(job) : res.status(404).json({ message: "Application not found" });
}
export async function deleteJob(req, res) {
  const job = await Job.findOneAndDelete({ _id: req.params.id, userId: req.user._id });
  if (!job) return res.status(404).json({ message: "Application not found" });
  await Interview.deleteMany({ jobId: job._id, userId: req.user._id });
  res.json({ message: "Deleted" });
}
