import { Router } from "express";
import { register, login, me } from "../controllers/authController.js";
import wrap from "../middleware/asyncHandler.js";
import protect from "../middleware/auth.js";
const r = Router();
r.post("/register", wrap(register)); r.post("/login", wrap(login)); r.get("/me", protect, wrap(me));
export default r;
