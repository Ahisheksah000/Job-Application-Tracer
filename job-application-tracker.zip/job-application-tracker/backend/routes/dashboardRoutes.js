import { Router } from "express";
import { getStats } from "../controllers/dashboardController.js";
import wrap from "../middleware/asyncHandler.js";
import protect from "../middleware/auth.js";
const r = Router();
r.get("/stats", protect, wrap(getStats));
export default r;
