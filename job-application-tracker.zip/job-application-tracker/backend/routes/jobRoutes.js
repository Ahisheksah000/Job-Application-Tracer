import { Router } from "express";
import { getJobs, createJob, getJob, updateJob, deleteJob } from "../controllers/jobController.js";
import wrap from "../middleware/asyncHandler.js";
import protect from "../middleware/auth.js";
const r = Router(); r.use(protect);
r.route("/").get(wrap(getJobs)).post(wrap(createJob));
r.route("/:id").get(wrap(getJob)).put(wrap(updateJob)).delete(wrap(deleteJob));
export default r;
