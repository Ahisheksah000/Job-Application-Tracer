import { Router } from "express";
import { getInterviews, createInterview, updateInterview, deleteInterview } from "../controllers/interviewController.js";
import wrap from "../middleware/asyncHandler.js";
import protect from "../middleware/auth.js";
const r = Router(); r.use(protect);
r.route("/").get(wrap(getInterviews)).post(wrap(createInterview));
r.route("/:id").put(wrap(updateInterview)).delete(wrap(deleteInterview));
export default r;
