import { createContext, useContext, useEffect, useState } from "react";
import api from "./api";
const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!localStorage.getItem("token"));
  useEffect(() => {
    if (!localStorage.getItem("token")) return;
    api.get("/auth/me").then((r) => setUser(r.data.user)).catch(() => localStorage.removeItem("token")).finally(() => setLoading(false));
  }, []);
  const authenticate = async (path, data) => {
    const r = await api.post(`/auth/${path}`, data);
    localStorage.setItem("token", r.data.token);
    setUser(r.data.user);
  };
  const logout = () => { localStorage.removeItem("token"); setUser(null); };
  return <AuthContext.Provider value={{ user, loading, login: (d) => authenticate("login", d), register: (d) => authenticate("register", d), logout }}>{children}</AuthContext.Provider>;
}
