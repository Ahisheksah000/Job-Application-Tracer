import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";
import Home from "./pages/Home";
import { Login, Register } from "./pages/AuthPages";
import Dashboard from "./pages/Dashboard";
import Applications from "./pages/Applications";
import { AddApplication, EditApplication } from "./pages/ApplicationForms";
import ApplicationDetails from "./pages/ApplicationDetails";
import Interviews from "./pages/Interviews";
import Profile from "./pages/Profile";
const P = (el) => <ProtectedRoute>{el}</ProtectedRoute>;
export default function App() {
  return (
    <>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={P(<Dashboard />)} />
          <Route path="/applications" element={P(<Applications />)} />
          <Route path="/applications/new" element={P(<AddApplication />)} />
          <Route path="/applications/:id" element={P(<ApplicationDetails />)} />
          <Route path="/applications/:id/edit" element={P(<EditApplication />)} />
          <Route path="/interviews" element={P(<Interviews />)} />
          <Route path="/profile" element={P(<Profile />)} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </>
  );
}
