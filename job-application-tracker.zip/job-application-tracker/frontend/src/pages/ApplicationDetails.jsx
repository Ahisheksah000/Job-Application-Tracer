import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import api, { errorMessage } from "../services/api";
import StatusBadge from "../components/StatusBadge";
const blank = { date: "", time: "", round: "Round 1", meetingLink: "", notes: "" };
export default function ApplicationDetails() {
  const { id } = useParams(); const navigate = useNavigate();
  const [job, setJob] = useState(null); const [interviews, setInterviews] = useState([]);
  const [form, setForm] = useState(blank); const [error, setError] = useState("");
  const load = () => Promise.all([api.get(`/jobs/${id}`), api.get("/interviews", { params: { jobId: id } })])
    .then(([j, i]) => { setJob(j.data); setInterviews(i.data); }).catch((e) => setError(errorMessage(e)));
  useEffect(() => { load(); }, [id]);
  const changeStatus = async (status) => { try { const r = await api.put(`/jobs/${id}`, { status }); setJob(r.data); } catch (e) { setError(errorMessage(e)); } };
  const remove = async () => {
    if (!window.confirm("Delete this application and its interviews?")) return;
    try { await api.delete(`/jobs/${id}`); navigate("/applications"); } catch (e) { setError(errorMessage(e)); }
  };
  const addInterview = async (e) => {
    e.preventDefault();
    if (!form.date) return setError("Interview date is required");
    try { await api.post("/interviews", { ...form, jobId: id }); setForm(blank); setError(""); load(); } catch (err) { setError(errorMessage(err)); }
  };
  const removeInterview = async (iid) => { if (window.confirm("Delete this interview?")) { await api.delete(`/interviews/${iid}`).catch((e) => setError(errorMessage(e))); load(); } };
  if (!job) return error ? <div className="error">{error}</div> : <p className="muted">Loading…</p>;
  const rows = [["Location", job.location], ["Salary", job.salary], ["Job Type", job.jobType], ["Work Mode", job.workMode], ["Application Date", new Date(job.applicationDate).toLocaleDateString()], ["Notes", job.notes]];
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  return (
    <>
      {error && <div className="error">{error}</div>}
      <div className="card">
        <h2 style={{ marginTop: 0 }}>{job.jobTitle} <span className="muted">at {job.companyName}</span></h2>
        <p><StatusBadge status={job.status} /></p>
        {rows.map(([l, v]) => <p key={l}><span className="muted">{l}:</span> {v || "—"}</p>)}
        <div className="row">
          <Link className="btn" to={`/applications/${id}/edit`}>Edit</Link>
          {job.jobUrl && <a className="btn ghost" href={job.jobUrl} target="_blank" rel="noreferrer">Open Job URL</a>}
          <select style={{ width: "auto" }} value={job.status} onChange={(e) => changeStatus(e.target.value)} aria-label="Change status">{["Applied", "Interview", "Offer", "Rejected", "Withdrawn"].map((s) => <option key={s}>{s}</option>)}</select>
          <button className="btn red" onClick={remove}>Delete</button>
        </div>
      </div>
      <div className="card"><h3 style={{ marginTop: 0 }}>Interviews</h3>
        {interviews.length === 0 && <p className="muted">No interviews added yet.</p>}
        {interviews.map((i) => <p key={i._id} className="row"><b>{i.round}</b> {new Date(i.date).toLocaleDateString()} {i.time}
          {i.meetingLink && <a href={i.meetingLink} target="_blank" rel="noreferrer">Meeting link</a>}{i.notes && <span className="muted">{i.notes}</span>}
          <a href="#" onClick={(e) => { e.preventDefault(); removeInterview(i._id); }}>Delete</a></p>)}
        <form onSubmit={addInterview} className="form" style={{ marginTop: 12 }}>
          <div><label>Date *</label><input type="date" value={form.date} onChange={set("date")} /></div>
          <div><label>Time</label><input type="time" value={form.time} onChange={set("time")} /></div>
          <div><label>Round</label><input value={form.round} onChange={set("round")} /></div>
          <div><label>Meeting Link</label><input value={form.meetingLink} onChange={set("meetingLink")} /></div>
          <div className="full"><label>Notes</label><input value={form.notes} onChange={set("notes")} /></div>
          <div><button className="btn">Add Interview</button></div>
        </form>
      </div>
    </>
  );
}
