import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { errorMessage } from "../services/api";
import StatusBadge from "../components/StatusBadge";
export default function Applications() {
  const [jobs, setJobs] = useState(null);
  const [q, setQ] = useState(""); const [status, setStatus] = useState(""); const [sort, setSort] = useState("newest");
  const [error, setError] = useState("");
  const load = () => api.get("/jobs", { params: { q, status, sort } }).then((r) => setJobs(r.data)).catch((e) => setError(errorMessage(e)));
  useEffect(() => { const t = setTimeout(load, 300); return () => clearTimeout(t); }, [q, status, sort]);
  const remove = async (id) => {
    if (!window.confirm("Delete this application? This cannot be undone.")) return;
    try { await api.delete(`/jobs/${id}`); load(); } catch (e) { setError(errorMessage(e)); }
  };
  return (
    <>
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 12 }}><h2 style={{ margin: 0 }}>Applications</h2><Link className="btn" to="/applications/new">+ Add Application</Link></div>
      <div className="card row">
        <input style={{ flex: 1, minWidth: 160 }} placeholder="Search company or job title" value={q} onChange={(e) => setQ(e.target.value)} />
        <select style={{ width: "auto" }} value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{["Applied", "Interview", "Offer", "Rejected", "Withdrawn"].map((s) => <option key={s}>{s}</option>)}</select>
        <select style={{ width: "auto" }} value={sort} onChange={(e) => setSort(e.target.value)}><option value="newest">Newest</option><option value="oldest">Oldest</option></select>
      </div>
      {error && <div className="error">{error}</div>}
      {!jobs ? <p className="muted">Loading…</p> : jobs.length === 0 ? <div className="card muted">No applications found.</div> :
        <div className="card table-wrap"><table><thead><tr><th>Company</th><th>Job Title</th><th>Location</th><th>Status</th><th>Date</th><th>Salary</th><th></th></tr></thead>
          <tbody>{jobs.map((j) => <tr key={j._id}><td>{j.companyName}</td><td>{j.jobTitle}</td><td>{j.location || "—"}</td><td><StatusBadge status={j.status} /></td><td>{new Date(j.applicationDate).toLocaleDateString()}</td><td>{j.salary || "—"}</td>
            <td className="row"><Link to={`/applications/${j._id}`}>View</Link><Link to={`/applications/${j._id}/edit`}>Edit</Link><a href="#" onClick={(e) => { e.preventDefault(); remove(j._id); }}>Delete</a></td></tr>)}</tbody></table></div>}
    </>
  );
}
