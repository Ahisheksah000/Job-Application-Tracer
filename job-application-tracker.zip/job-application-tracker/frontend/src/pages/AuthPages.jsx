import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
import { errorMessage } from "../services/api";
function AuthForm({ mode }) {
  const { user, login, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/dashboard" />;
  const isLogin = mode === "login";
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const submit = async (e) => {
    e.preventDefault();
    if (!isLogin && !form.name.trim()) return setError("Name is required");
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError("Enter a valid email");
    if (form.password.length < 6) return setError("Password must be at least 6 characters");
    setBusy(true); setError("");
    try { await (isLogin ? login(form) : register(form)); navigate("/dashboard"); }
    catch (err) { setError(errorMessage(err)); setBusy(false); }
  };
  return (
    <form className="card center" onSubmit={submit}>
      <h2>{isLogin ? "Login" : "Create account"}</h2>
      {error && <div className="error">{error}</div>}
      {!isLogin && <p><label>Name</label><input value={form.name} onChange={set("name")} /></p>}
      <p><label>Email</label><input type="email" value={form.email} onChange={set("email")} /></p>
      <p><label>Password</label><input type="password" value={form.password} onChange={set("password")} /></p>
      <button className="btn" disabled={busy}>{busy ? "Please wait…" : isLogin ? "Login" : "Register"}</button>
      <p className="muted">{isLogin ? <>No account? <Link to="/register">Register</Link></> : <>Have an account? <Link to="/login">Login</Link></>}</p>
    </form>
  );
}
export const Login = () => <AuthForm mode="login" />;
export const Register = () => <AuthForm mode="register" />;
