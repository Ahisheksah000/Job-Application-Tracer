import { useAuth } from "../services/AuthContext";
export default function Profile() {
  const { user } = useAuth();
  return (
    <div className="card">
      <h2 style={{ marginTop: 0 }}>Profile</h2>
      <p><span className="muted">Name:</span> {user.name}</p>
      <p><span className="muted">Email:</span> {user.email}</p>
      <p><span className="muted">Member since:</span> {new Date(user.createdAt).toLocaleDateString()}</p>
    </div>
  );
}
