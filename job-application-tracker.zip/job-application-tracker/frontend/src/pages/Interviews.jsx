import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { errorMessage } from "../services/api";
export default function Interviews() {
  const [list, setList] = useState(null); const [error, setError] = useState("");
  const load = () => api.get("/interviews").then((r) => setList(r.data)).catch((e) => setError(errorMessage(e)));
  useEffect(() => { load(); }, []);
  const remove = async (id) => { if (window.confirm("Delete this interview?")) { await api.delete(`/interviews/${id}`).catch((e) => setError(errorMessage(e))); load(); } };
  return (
    <>
      <h2>Interviews</h2>
      {error && <div className="error">{error}</div>}
      {!list ? <p className="muted">Loading…</p> : list.length === 0 ? <div className="card muted">No interviews yet. Open an application to add one.</div> :
        <div className="card table-wrap"><table><thead><tr><th>Company</th><th>Round</th><th>Date</th><th>Time</th><th>Link</th><th></th></tr></thead>
          <tbody>{list.map((i) => <tr key={i._id}><td>{i.jobId ? <Link to={`/applications/${i.jobId._id}`}>{i.jobId.companyName}</Link> : "—"}</td><td>{i.round}</td><td>{new Date(i.date).toLocaleDateString()}</td><td>{i.time || "—"}</td>
            <td>{i.meetingLink ? <a href={i.meetingLink} target="_blank" rel="noreferrer">Join</a> : "—"}</td><td><a href="#" onClick={(e) => { e.preventDefault(); remove(i._id); }}>Delete</a></td></tr>)}</tbody></table></div>}
    </>
  );
}
