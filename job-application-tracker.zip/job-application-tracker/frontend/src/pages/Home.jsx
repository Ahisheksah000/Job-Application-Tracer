import { Link } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
export default function Home() {
  const { user } = useAuth();
  return (
    <div className="hero">
      <h1>Track every job application in one place</h1>
      <p className="muted">Save applications, follow their status and never miss an interview.</p>
      <p>{user ? <Link className="btn" to="/dashboard">Go to Dashboard</Link> : <><Link className="btn" to="/register">Get Started</Link> <Link className="btn ghost" to="/login">Login</Link></>}</p>
    </div>
  );
}
