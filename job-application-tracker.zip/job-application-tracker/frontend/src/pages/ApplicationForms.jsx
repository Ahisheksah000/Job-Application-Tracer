import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { errorMessage } from "../services/api";
import JobForm from "../components/JobForm";
export function AddApplication() {
  const navigate = useNavigate();
  return <><h2>Add Application</h2><JobForm submitLabel="Save Application" onSubmit={async (d) => { await api.post("/jobs", d); navigate("/applications"); }} /></>;
}
export function EditApplication() {
  const { id } = useParams(); const navigate = useNavigate();
  const [job, setJob] = useState(null); const [error, setError] = useState("");
  useEffect(() => { api.get(`/jobs/${id}`).then((r) => setJob(r.data)).catch((e) => setError(errorMessage(e))); }, [id]);
  if (error) return <div className="error">{error}</div>;
  if (!job) return <p className="muted">Loading…</p>;
  return <><h2>Edit Application</h2><JobForm initial={job} submitLabel="Update Application" onSubmit={async (d) => { await api.put(`/jobs/${id}`, d); navigate(`/applications/${id}`); }} /></>;
}
