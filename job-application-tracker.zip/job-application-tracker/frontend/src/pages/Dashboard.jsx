import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api, { errorMessage } from "../services/api";
import StatusBadge from "../components/StatusBadge";
export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => { api.get("/dashboard/stats").then((r) => setStats(r.data)).catch((e) => setError(errorMessage(e))); }, []);
  if (error) return <div className="error">{error}</div>;
  if (!stats) return <p className="muted">Loading…</p>;
  const cards = [["Total", stats.total], ["Applied", stats.applied], ["Interview", stats.interview], ["Offer", stats.offer], ["Rejected", stats.rejected]];
  return (
    <>
      <div className="row" style={{ justifyContent: "space-between", marginBottom: 12 }}><h2 style={{ margin: 0 }}>Dashboard</h2><Link className="btn" to="/applications/new">+ Add Application</Link></div>
      <div className="grid" style={{ marginBottom: 16 }}>{cards.map(([l, v]) => <div key={l} className="card stat" style={{ marginBottom: 0 }}><b>{v}</b><span>{l}</span></div>)}</div>
      <div className="card"><h3>Recent Applications</h3>
        {stats.recent.length === 0 ? <p className="muted">No applications yet. Add your first one!</p> :
          stats.recent.map((j) => <p key={j._id} className="row"><Link to={`/applications/${j._id}`}>{j.companyName} — {j.jobTitle}</Link><StatusBadge status={j.status} /></p>)}</div>
      <div className="card"><h3>Upcoming Interviews</h3>
        {stats.upcoming.length === 0 ? <p className="muted">No upcoming interviews.</p> :
          stats.upcoming.map((i) => <p key={i._id}><b>{i.jobId?.companyName}</b> · {i.round} · {new Date(i.date).toLocaleDateString()} {i.time}</p>)}</div>
    </>
  );
}
