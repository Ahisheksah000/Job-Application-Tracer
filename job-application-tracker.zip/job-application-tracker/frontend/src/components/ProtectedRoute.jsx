import { Navigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
export default function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <p className="container muted">Loading…</p>;
  return user ? children : <Navigate to="/login" replace />;
}
