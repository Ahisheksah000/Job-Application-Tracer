import { useState } from "react";
import { errorMessage } from "../services/api";
const empty = { companyName: "", jobTitle: "", location: "", jobType: "Full Time", workMode: "On-site", salary: "", jobUrl: "", applicationDate: new Date().toISOString().slice(0, 10), status: "Applied", notes: "" };
export default function JobForm({ initial, onSubmit, submitLabel }) {
  const [form, setForm] = useState({ ...empty, ...initial, applicationDate: (initial?.applicationDate || empty.applicationDate).slice(0, 10) });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const select = (k, label, options) => (
    <div><label>{label}</label><select value={form[k]} onChange={set(k)}>{options.map((o) => <option key={o}>{o}</option>)}</select></div>
  );
  const submit = async (e) => {
    e.preventDefault();
    if (!form.companyName.trim() || !form.jobTitle.trim()) return setError("Company name and job title are required");
    if (form.jobUrl && !/^https?:\/\//i.test(form.jobUrl)) return setError("Job URL must start with http:// or https://");
    setSaving(true); setError("");
    try { await onSubmit(form); } catch (err) { setError(errorMessage(err)); setSaving(false); }
  };
  return (
    <form className="card" onSubmit={submit}>
      {error && <div className="error">{error}</div>}
      <div className="form">
        <div><label>Company Name *</label><input value={form.companyName} onChange={set("companyName")} /></div>
        <div><label>Job Title *</label><input value={form.jobTitle} onChange={set("jobTitle")} /></div>
        <div><label>Location</label><input value={form.location} onChange={set("location")} /></div>
        {select("jobType", "Job Type", ["Full Time", "Part Time", "Internship", "Contract"])}
        {select("workMode", "Work Mode", ["Remote", "Hybrid", "On-site"])}
        <div><label>Salary</label><input value={form.salary} onChange={set("salary")} placeholder="e.g. $80k–100k" /></div>
        <div><label>Job URL</label><input value={form.jobUrl} onChange={set("jobUrl")} placeholder="https://…" /></div>
        <div><label>Application Date</label><input type="date" value={form.applicationDate} onChange={set("applicationDate")} /></div>
        {select("status", "Status", ["Applied", "Interview", "Offer", "Rejected", "Withdrawn"])}
        <div className="full"><label>Notes</label><textarea rows="4" value={form.notes} onChange={set("notes")} /></div>
      </div>
      <p><button className="btn" disabled={saving}>{saving ? "Saving…" : submitLabel}</button></p>
    </form>
  );
}
