import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../services/AuthContext";
export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const toggleTheme = () => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    localStorage.setItem("theme", next);
  };
  return (
    <nav className="nav">
      <Link to="/" className="brand">JobTracker</Link>
      {user && <><Link to="/dashboard">Dashboard</Link><Link to="/applications">Applications</Link><Link to="/interviews">Interviews</Link><Link to="/profile">Profile</Link></>}
      <span className="sp" />
      <button className="btn ghost" onClick={toggleTheme} aria-label="Toggle dark mode">Theme</button>
      {user ? <button className="btn ghost" onClick={() => { logout(); navigate("/"); }}>Logout</button>
        : <><Link to="/login">Login</Link><Link to="/register" className="btn">Register</Link></>}
    </nav>
  );
}
