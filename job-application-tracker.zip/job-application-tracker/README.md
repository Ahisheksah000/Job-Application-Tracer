# Job Application Tracker (MERN)
See the setup and deployment steps in the chat reply. Quick start:
1. `cd backend && cp .env.example .env` (fill in MONGO_URI and JWT_SECRET) `&& npm install && npm run dev`
2. `cd frontend && cp .env.example .env && npm install && npm run dev`
3. Open http://localhost:5173
